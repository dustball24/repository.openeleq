addon_id="script.icechannel.iStream.about.settings"
addon_name="iStream - About - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
