addon_id="script.icechannel.iStream.live_tv.settings"
addon_name="iStream - Live TV - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
